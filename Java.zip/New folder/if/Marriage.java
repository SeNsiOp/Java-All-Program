class Marriage{
public static void main(String[] args){
int age = 21;
System.out.println("main Start");
if(age>20){
System.out.println("Eligible");
}
System.out.println("main End");
}}