class Check{
public static void main(String[] args){
int a=6;
if(a%2==0){
System.out.println("Even");
}
else
System.out.println("Odd");
}
}