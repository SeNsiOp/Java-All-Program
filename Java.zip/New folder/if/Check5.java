class Check5{
public static void main(String[] args){
double length = 6;
double width = 4;
double area = length * width;
System.out.println("Area of Rectangle is "+area);
}}