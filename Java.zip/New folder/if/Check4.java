class Check4{
public static void main(String[] args){
double radius = 5;
double height = 10;
double volume = (1.0/3.0) * 3.14159 * radius * radius * height;
System.out.println("Volume of Cone is "+ volume);
}}