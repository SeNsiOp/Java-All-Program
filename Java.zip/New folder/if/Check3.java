class Check3{
public static void main(String[] args){
int age = 18;
if(age>=18){
System.out.println(age+" Age Eligible for Vote");
}
else{
System.out.println(age+" Age Not Eligible for Vote");
}
}}