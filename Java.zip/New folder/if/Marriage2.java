class Marriage2{
public static void main(String[] args){
System.out.println("main Start");
int age = 21;

if(age>20)

System.out.println("Eligible");
System.out.println("Eligible");

System.out.println("main End");
}}