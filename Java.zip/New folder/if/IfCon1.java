class IfCon1{
public static void main(String[] args){
int age = 18;
if(age>=18){
System.out.println(age+" is Eligible for Voting");
}
else
System.out.println("oh! No!! You are not Eligible!! --> Come Again when You are Eligible");
}}