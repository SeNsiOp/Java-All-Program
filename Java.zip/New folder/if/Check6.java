class Check6{
public static void main(String[] args){
int num1 = 4;
int num2 = 4;
if(num1==num2){
System.out.println(num1+" & "+num2+" is Same");
}
else
System.out.println(num1+" & "+num2+" is Not Same");
}}