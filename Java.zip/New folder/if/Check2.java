class Check2{
public static void main(String[] args){
char ch= 'A';
if(ch>=65 && ch<=90){
System.out.println(ch+" is UPPERCASE");
}
else if(ch>=97 && ch<=122){
System.out.println(ch+" is lowercase");
}
else if(ch>=48 && ch<=57){
System.out.println(ch+" is Digit");
}
else
System.out.println("Wrong Character Input");
}}

