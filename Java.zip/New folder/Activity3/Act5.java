class Act5{
public static void main(String[] args){
int num1 = 40;
int num2 = 30;
int num3 = 56;
int num4 = 78;
int addAllNumber = num1+num2+num3+num4;
float average = addAllNumber/4;
System.out.print("Average = "+average);
}
} 