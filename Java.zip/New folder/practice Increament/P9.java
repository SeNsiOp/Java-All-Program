class P9{
public static void main(String[] args){
int i=19;
int j=29;
int k;
k=i-- - i++ + --j - ++j + --i - j-- + ++i - j++;
System.out.print(k);
}}