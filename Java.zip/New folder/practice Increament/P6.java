class P6{
public static void main(String[] args){
boolean b=true;
b=b++;
System.out.print(b);
}}