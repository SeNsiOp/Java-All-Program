class P2{
public static void main(String[] args){
int a=10;
int b=20;
int c=3;
int d=c= --a + --b + b++ -c -a + ++a - c++ - a++;
System.out.print(d);
}}