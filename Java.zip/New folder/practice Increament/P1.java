class P1{
public static void main(String[] args){
int a=10;
int b=20;
int c= a++ + b+ ++a - --a - --a + ++b -b;
System.out.print(c);
}}