class P4{
public static void main(String[] args){
int i=11;
i=i++ + ++i;
System.out.print(i);
}}