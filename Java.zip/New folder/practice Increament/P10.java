class P10{
public static void main(String[] args){
int i=11;
int j= --(i++);
System.out.print(j);
}}