class P8{
public static void main(String[] args){
int a=1;
int b=2;
int c= --b - ++a + ++b - --a;
System.out.print(c);
}}