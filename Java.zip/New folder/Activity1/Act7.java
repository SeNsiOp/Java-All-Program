class Act7{
public static void main(String[] args){
System.out.print(2+4+6+8+10+12+14+16+18+20);
}
}