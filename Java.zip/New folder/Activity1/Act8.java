class Act8{
public static void main(String[] args){
System.out.print(21*23*25*27*29);
}
}