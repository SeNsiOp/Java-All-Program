class Act9{
public static void main(String[] args){
System.out.print(2+3+5+7+11+13+17+19);
}
}