class Act1{
public static void main(String[] args){
System.out.print(10/5);
}
}