class Check6{
public static void main(String[] args){
char a = 'V';
String result = a<90?"UPPERCASE":"lowercase";
System.out.println(result);
}}