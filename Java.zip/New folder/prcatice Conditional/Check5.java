class Check5{
public static void main(String[] args){
int num1=12;
int num2=6;
int num3=5;
int result= (num1>num2)? (num1>num3?num1:num3) : (num2>num3?num2:num3);
System.out.println(result+" is Greater");
}}