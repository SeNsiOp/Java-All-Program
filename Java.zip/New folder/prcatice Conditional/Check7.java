class Check7{
public static void main(String[] args){
int a = 18;
String result = a>=18?"Eligible":"Not Eligible";
System.out.println(a+" is "+result);
}}