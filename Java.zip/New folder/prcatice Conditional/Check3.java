class Check3{
public static void main(String[] args){
int num = 24;
int num2 = 25;
String result= num%5==0?"Divisible":"Not";
System.out.println("24 "+result);

String result2 = num2%5==0?"Divisible":"Not";
System.out.println("25 "+result2);
}}