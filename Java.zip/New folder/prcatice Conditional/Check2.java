class Check2{
public static void main(String[] args){
int num= 5;
int num2 = -2;
String result = num<0?"Negative":"Postive";
System.out.println("5 "+result);

String result2 = num2<0?"Negative":"Postive";
System.out.println("-2 "+result2);

}}