class Check{
public static void main(String[] args){
int num= 5;
String result = num%2==0?"Even":"Odd";
System.out.print(result);
}}