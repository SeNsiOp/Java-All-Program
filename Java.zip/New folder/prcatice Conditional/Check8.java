class Check8{
public static void main(String[] args){
int num = 14;
int num2 = 13;
String result = num%7==0?"Divisible":"Not Divisible";
System.out.println(num +" is "+result);

String result2 = num2%7==0?"Divisible":"Not Divisible";
System.out.println(num2 +" is "+result2);

}}