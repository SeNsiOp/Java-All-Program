class Check4{
public static void main(String[] args){
int num1=2;
int num2=4;
String result= num1>num2?"2 is Greater":"4 is Greater";
System.out.println(result);
}}