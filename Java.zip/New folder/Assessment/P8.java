class P8{
public static void main(String[] args){
System.out.println("Division = "+(53/10));
System.out.println("Modulus = "+(53%10));
}}