class P2{
public static void main(String[] args){
System.out.println("Division = "+(54.0/2));
System.out.println("Modulus = "+(54.0%2));
}}