class P4{
public static void main(String[] args){
System.out.println("Division = "+(32.0/2));
System.out.println("Modulus = "+(32.0%2.0));
}}