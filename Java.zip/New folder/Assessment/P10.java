class P10{
public static void main(String[] args){
System.out.println("Division = "+(5/0));
System.out.println("Modulus = "+(5%0));
}}