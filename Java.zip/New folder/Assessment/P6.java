class P6{
public static void main(String[] args){
System.out.println("Division = "+(5371/10));
System.out.println("Modulus = "+(5371%10));
}}