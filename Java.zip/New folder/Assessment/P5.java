class P5{
public static void main(String[] args){
System.out.println("Division = "+(38.0/2.5));
System.out.println("Modulus = "+(38.0%2.5));
}}