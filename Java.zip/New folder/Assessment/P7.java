class P7{
public static void main(String[] args){
System.out.println("Division = "+(537/10));
System.out.println("Modulus = "+(537%10));
}}