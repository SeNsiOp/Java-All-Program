class P1{
public static void main(String[] args){
System.out.println("Division = "+(53.5/2));
System.out.println("Modulus = "+(53.5%2));
}}