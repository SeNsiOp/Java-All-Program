class P9{
public static void main(String[] args){
System.out.println("Division = "+(5/10));
System.out.println("Modulus = "+(5%10));
}}