class Sum{
public static void main(String[] args){
int num1=5;
int num2=10;
System.out.println("Sum of Num1=5 & Num2=10 Total="+(num1+num2));
}}