class Sum4{
public static void main(String[] args){
short num1=25;
short num2= 15;
System.out.println("Sum = "+(num1+num2));
}
}