class Sum3{
public static void main(String[] args){
byte num1=5;
byte num2= 10;
System.out.println("Sum = "+(num1+num2));
}
}