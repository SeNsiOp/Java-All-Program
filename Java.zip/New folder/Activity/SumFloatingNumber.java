class SumFloatingNumber{
public static void main(String[] args){
float num1=5.5f;
float num2=10.2f;
System.out.println("Sum ="+(num1+num2));
}
}