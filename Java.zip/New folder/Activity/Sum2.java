class Sum2{
public static void main(String[] args){
int num1=5;
float num2= 10.2f;
float num3= 22.4f;
System.out.println("Sum = "+(num1+num2+num3));
}
}