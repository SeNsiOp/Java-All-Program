class School{
public static void main(String[] args){

int ram=4;
int hari=7;
int raghu=9;
int shyam=11;

System.out.println("Ram 4 pen + Hari 7 pen + Raghu 9 pen + Shyam 11 pen Total pens = "+(ram+hari+raghu+shyam));
}
}
